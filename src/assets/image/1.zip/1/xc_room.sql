-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2020-08-20 10:44:26
-- 服务器版本： 10.1.28-MariaDB
-- PHP Version: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `xc`
--

-- --------------------------------------------------------

--
-- 表的结构 `xc_room`
--

CREATE TABLE `xc_room` (
  `lid` int(11) NOT NULL,
  `title` varchar(128) DEFAULT NULL,
  `subtitle` varchar(128) DEFAULT NULL,
  `price` decimal(7,2) DEFAULT NULL,
  `position` varchar(64) DEFAULT NULL,
  `rtype` varchar(64) DEFAULT NULL,
  `img1` varchar(128) DEFAULT NULL,
  `img2` varchar(128) DEFAULT NULL,
  `img3` varchar(128) DEFAULT NULL,
  `imgs` varchar(128) DEFAULT NULL,
  `area` smallint(6) DEFAULT NULL,
  `ruzhuriqi` varchar(32) DEFAULT NULL,
  `wholeRenting` varchar(32) DEFAULT NULL,
  `bed` tinyint(1) DEFAULT NULL,
  `wifi` tinyint(1) DEFAULT NULL,
  `washing` tinyint(1) DEFAULT NULL,
  `air_conditioner` tinyint(1) DEFAULT NULL,
  `toilet` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `xc_room`
--

INSERT INTO `xc_room` (`lid`, `title`, `subtitle`, `price`, `position`, `rtype`, `img1`, `img2`, `img3`, `imgs`, `area`, `ruzhuriqi`, `wholeRenting`, `bed`, `wifi`, `washing`, `air_conditioner`, `toilet`) VALUES
(null, '万象天成 龙岗中心城 精美单间 家私电齐全 押一付一好停车', '龙岗-龙岗中心城-万象天成', '980.00', '龙岗', '1室', '1.jpg', '1.jpg', '1.jpg', '1.jpg', 26, '可随时入住', '整租', 1, 1, 1, 1, 1),
(null, '振业峦山谷 精装2房 诚心出租 带全部家私家电', '龙岗-横岗-振业峦山谷', '1900.00', '龙岗', '2室1厅', '2.jpg', '2.jpg', '2.jpg', '2.jpg', 56, '可随时入住', '整租', 1, 1, 1, 1, 1),
(null, '精装修两房一厅 大阳台 近地铁 配套齐全 拎包入组 全新家私', '龙华区-龙华-富联新村', '2000.00', '龙华', '2室1厅', '3.jpg', '3.jpg', '3.jpg', '3.jpg', 50, '可随时入住', '整租', 1, 1, 1, 1, 1),
(null, '地铁口物业,楼下生活配套成熟', '龙华区-龙华-莱蒙水榭春天五期', '890.00', '龙华', '1室1厅', '4.png', '4.png', '4.jpg', '4.png', 46, '可随时入住', '整租', 1, 1, 0, 1, 1),
(null, '11号线沙井 精装 家私电齐窗户让你的生活充满阳光', '宝安-沙井-鸿荣源禧园', '1200.00', '宝安', '1室1厅', '5.jpg', '5.jpg', '5.jpg', '5.jpg', 35, '可随时入住', '整租', 1, 1, 1, 1, 1),
(null, '龙辉花园 合租 主卧87.7平米4室1厅1卫性别不限', '南山-后海-京光海景花园', '1800.00', '南山', '4室1厅', '6.jpg', '6.jpg', '6.jpg', '6.jpg', 88, '可随时入住', '合租', 1, 1, 1, 1, 1),
(null, '淘金山湖景花园 客厅出阳台可看东湖水库 梧桐山风光 豪华鼎复', '罗湖-水库-淘金山湖景花园', '7900.00', '罗湖', '3室1厅', '100.jpg', '100.jpg', '100.jpg', '100.jpg', 68, '可随时入住', '整租', 1, 1, 1, 1, 1),
(null, '名骏豪庭精装小三房,看小区花园,卧室出阳台,干净整洁', '罗湖-莲塘-名骏豪庭', '5000.00', '罗湖', '3室1厅', '101.jpg', '101.jpg', '101.jpg', '101.jpg', 69, '可随时入住', '整租', 1, 1, 1, 1, 1),
(null, '凤凰印象 简洁舒适 一房一厅 拎包入住 高层景观 看房方便', '罗湖-黄贝岭-凤凰印象', '4200.00', '罗湖', '1室1厅', '102.jpg', '102.jpg', '102.jpg', '102.jpg', 42, '可随时入住', '整租', 1, 1, 1, 1, 1),
(null, '东乐花园, 幽静中的小区,适宜', '罗湖-布心-东乐花园', '4500.00', '罗湖', '2室1厅', '103.jpg', '103.jpg', '103.jpg', '103.jpg', 76, '可随时入住', '整租', 1, 1, 1, 1, 1),
(null, '罗湖口岸双地铁口一房一厅出租3600', '罗湖-人民南-置地逸轩', '3600.00', '罗湖', '1室1厅', '104.jpg', '104.jpg', '104.jpg', '104.jpg', 39, '可随时入住', '整租', 1, 1, 1, 1, 1),
(null, '地铁口 卧室出阳台 精美两房 家私齐全 拎包入住 业主心诚租', '罗湖-布心-大地花园', '3600.00', '罗湖', '2室1厅', '105.jpg', '105.jpg', '105.jpg', '105.jpg', 46, '可随时入住', '整租', 1, 1, 1, 1, 1),
(null, '京基御景一期,租2700双大阳台正看花园游泳池,带全家电', '坪山区-坪山-京基·御景印象', '2700.00', '坪山', '3室1厅', '106.jpg', '106.jpg', '106.jpg', '106.jpg', 89, '可随时入住', '合租', 1, 0, 1, 1, 1),
(null, '新房源!坪山京基御景一房一厅,家电齐全,拎包入住,随时看房', '坪山区-坪山-京基·御景印象', '1700.00', '坪山', '1室1厅', '107.jpg', '107.jpg', '107.jpg', '107.jpg', 45, '可随时入住', '整租', 1, 1, 1, 1, 1),
(null, '网红大盘公馆业主诚心出租空房可以按要求配齐吃住一条街', '坪山区-坪山-深城投·中心公馆', '1100.00', '坪山', '1室1厅', '108.jpg', '108.jpg', '108.jpg', '108.jpg', 41, '可随时入住', '整租', 1, 1, 1, 1, 1),
(null, '拎包入住,业主随和,需要什么添加什么,交通生活方便,', '坪山区-坪山-龙光玖云著', '1800.00', '坪山', '2室1厅', '109.jpg', '109.jpg', '109.jpg', '109.jpg', 52, '可随时入住', '整租', 1, 1, 1, 1, 1),
(null, '坪山高铁站旁 精装修一房家私齐全 业主好说话 看房方便', '坪山区-坪山-深城投·中心公馆', '1300.00', '坪山', '1室1厅', '110.jpg', '110.jpg', '110.jpg', '110.jpg', 33, '可随时入住', '整租', 1, 1, 1, 1, 1),
(null, '坪山天虹,精装两房出租,家私家电齐全,拎包入住', '坪山区-坪山-龙光玖云著', '1800.00', '坪山', '2室1厅', '111.jpg', '111.jpg', '111.jpg', '111.jpg', 52, '可随时入住', '整租', 1, 1, 1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `xc_room`
--
ALTER TABLE `xc_room`
  ADD PRIMARY KEY (`lid`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `xc_room`
--
ALTER TABLE `xc_room`
  MODIFY `lid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
