//引入路由器
//引入body-parser中间件
const express = require('express');

//引入跨域中间件cors
const cors = require('cors');

// const mysql = require('mysql');

const bodyParser = require('body-parser');

const { Console } = require('console');

const pool = require('./pool');

const app = express();

app.listen(3000);

app.use(cors({
  origin: ['http://127.0.0.1:8080', 'http://localhost:8080']
}));

app.use(bodyParser.urlencoded({
  extended:false
}));

app.get('/fang',(req,res)=>{
  let {position,price,area,title}= req.query;
  if(position==undefined && price == undefined && area==undefined && title==undefined||title==''){
    var sql ='SELECT * FROM xc_room '
  }else if(title){
    title='%'+title+'%'
    var sql= "SELECT * FROM xc_room where title like ? or subtitle like ? or price like ? or rtype  like ?"
    var arr=[title,title,title,title];
  }else{
    position = position.split('区')[0];
    var prices=price.split(/-|以上/)[0];
    var priceg=price.split(/-|以上/)[1];
    priceg=priceg==''?4000000:priceg;
    var areas=area.split(/m²-|m²/)[0];
    var areag=area.split(/m²-|m²/)[1];
    areag = areag == '以上' ? 1000000 : areag;
    var sql ='SELECT * FROM xc_room '+where ;
    var arr=[];
    if (position!='位置') arr.push(position);
    if(price!='价格'){
      arr.push(prices);
      arr.push(priceg);
    }
    if(area!='面积'){
      arr.push(areas);
      arr.push(areag);
    }
  }

  pool.query(sql,arr,(err,result)=>{
    if (err) throw err;
    res.send({message:'查询成功',code:1,result:result})
  })
})

// app.get('/123', (req, res) => {
//   let sql = 'SELECT id,category_name FROM xzqa_category'
//   pool.query(sql, (err, result) => {
//     if (err) throw err;
//     console.log(result);
//     res.send({ message: '查询成功', code: 1, result: result });
//   });
// });

// app.get('/articles', (req, res) => {
//   let cid = Number(req.query.cid);
//   console.log(cid);
//   let page = req.query.yeshu;
//   console.log(page);
//   let offset = page * 20;
//   let sql = "SELECT COUNT(id) AS count FROM xzqa_article WHERE category_id=?";
//   pool.query(sql, [cid], (err, result) => {
//     if (err) throw err;
//     console.log(result);
//     let rowcount = result[0].count;
//     let pagesize = 20;
//     let pagecount = Math.ceil(rowcount / pagesize);
//     sql = 'SELECT id,subject,description,image FROM xzqa_article WHERE category_id=? LIMIT ' + offset + ',' + pagesize;
//     pool.query(sql, [cid], (err, results) => {
//       if (err) throw err;
//       res.send({
//         message: '查询成功', code: 1, articles: results,
//         pagecount: pagecount
//       })
//     })
//   })
// })

// app.get('/articles',(req,res)=>{
//   let cid = Number(req.query.cid);
//   let yeshu = req.query.yeshu;
//   let sql='SELECT COUNT(id) AS count FROM xzqa_article WHERE category_id=? '
//   pool.query(sql, [cid], (err, results) => {
//     if (err) throw err;
//     let rowcount = results[0].count;
//     let pagesize = 20;
//     let pagecount = Math.ceil(rowcount / pagesize);
//     sql='SELECT id,subject,description,image FROM xzqa_article WHERE category_id=?  LIMIT '+(yeshu-1)*pagesize+','+pagesize
//     console.log(yeshu*pagesize);
//     pool.query(sql,[cid],(err,result)=>{
//       if(err) throw err;
//       res.send({message:'查询成功',code:1,result:result,pagecount:pagecount});
//     });
//   });
// });

// app.get('/article',(req,res)=>{
//   let id=req.query.id;
//   let sql='SELECT a.id,subject,content,nickname,avatar,article_number,created_at from xzqa_article AS a INNER JOIN xzqa_author AS b ON author_id=b.id where a.id=?';
//   pool.query(sql,[id],(err,result)=>{
//     if(err) throw err;
// 	  console.log(result);
//     res.send({message:'查询成功',code:1,result:result[0]});
//   })
// })

// app.post('/field',(req,res)=>{
//   let uname=req.body.uname
//   let upwd=req.body.upwd
//   let sql='SELECT COUNT(id) AS count FROM xzqa_author WHERE username=? '
//   pool.query(sql,[uname],(err,result)=>{
//     console.log(result);
//     if (result[0].count==0){
//       sql='INSERT xzqa_author(username,password) VALUES(?,MD5(?))'
//       pool.query(sql,[uname,upwd],(err,results)=>{
//         if (err) throw err
//         res.send({message:'注册成功',code:1})
//       })
//     } else {
//       res.send({message:'注册失败',code:0})
//     }
//   })
// })

// // UPDATE xzqa_author AS a INNER JOIN (SELECT COUNT(id) AS count,author_id FROM xzqa_article GROUP BY author_id) AS b ON b.author_id = a.id SET article_number = b.count;
// app.post('/login',(req,res)=>{
//   console.log(req.body);
//   let uname=req.body.uname
//   let upwd=req.body.upwd
//   let sql='select id,username,nickname from xzqa_author where username=? and password=MD5(?)';
//   pool.query(sql,[uname,upwd],(err,result)=>{
//     if (err) throw err;
//     if(result.length == 1){
//       res.send({message:'登陆成功',code:1})
//     }else{
//       res.send({message:'登录失败',code:0})
//     }
//   })
// })